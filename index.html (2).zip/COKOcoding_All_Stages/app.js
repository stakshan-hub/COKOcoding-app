const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORE_KEY = "cokocoding_all_projects_v1";
const PROFILE_KEY = "cokocoding_profile_v1";
const starter = {
  html: '<main class="card">\n  <div class="spark">✦</div>\n  <p class="tag">MY FIRST PROJECT</p>\n  <h1>Hello, Coder!</h1>\n  <p class="description">Welcome to my little corner of the internet.</p>\n  <button id="helloBtn">Click me</button>\n  <p id="message"></p>\n</main>',
  css: 'body {\n  margin: 0;\n  min-height: 100vh;\n  display: grid;\n  place-items: center;\n  font-family: system-ui, sans-serif;\n  background: linear-gradient(135deg, #f3efff, #e6fbf4);\n  color: #242039;\n}\n.card { text-align: center; padding: 38px; background: white; border-radius: 24px; box-shadow: 0 20px 60px #33205b18; max-width: 360px; }\n.spark { font-size: 34px; color: #7b5cff; }\n.tag { font-size: 10px; letter-spacing: 2px; color: #7b5cff; font-weight: 800; }\nh1 { margin: 10px 0; }\n.description { color: #747187; line-height: 1.6; }\nbutton { border: 0; background: #7357f6; color: white; padding: 12px 20px; border-radius: 10px; cursor: pointer; font-weight: 700; }\nbutton:hover { background: #5b40d7; }',
  js: 'const button = document.querySelector("#helloBtn");\nbutton.addEventListener("click", () => {\n  document.querySelector("#message").textContent = "You did it! Keep coding ✨";\n});'
};
let activeTab = "html";
let runCount = 0;
let projects = loadProjects();
let currentId = projects[0]?.id || null;
let toastTimer;

function uid(){ return "p_" + Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
function loadProjects(){
  try {
    const saved = JSON.parse(localStorage.getItem(STORE_KEY) || "[]");
    if (Array.isArray(saved) && saved.length) return saved;
  } catch(e) {}
  return [{id:uid(),name:"My first webpage",html:starter.html,css:starter.css,js:starter.js,updated:Date.now()}];
}
function toast(message){
  const el=$("#toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2600);
}
function persist(show=true){
  try { localStorage.setItem(STORE_KEY,JSON.stringify(projects)); }
  catch(e){ toast("Browser storage is full. Export a backup."); return; }
  updateStats(); renderProjects();
  $("#saveStatus").textContent="● Saved locally";
  if(show) toast("Project saved in this browser.");
}
function currentProject(){ return projects.find(p=>p.id===currentId) || projects[0]; }
function syncEditorToProject(){
  const p=currentProject(); if(!p)return;
  p[activeTab]=$("#codeEditor").value;
  p.updated=Date.now();
}
function switchTab(tab){
  syncEditorToProject(); activeTab=tab;
  $$(".file-tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
  $("#codeEditor").value=currentProject()?.[tab] ?? "";
  $("#editorLang").textContent=tab==="js"?"JAVASCRIPT":tab.toUpperCase();
}
function buildDocument(p){
  const safeJs=p.js.replace(/<\/script/gi,"<\\/script");
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${p.css}</style></head><body>${p.html}<script>try{${safeJs}}catch(e){console.error(e.message)}<\/script></body></html>`;
}
function runCode(){
  syncEditorToProject();
  $("#preview").srcdoc=buildDocument(currentProject());
  $("#consoleOutput").textContent="Preview refreshed. (Browser console messages may not appear in this panel.)";
  runCount++; $("#runCount").textContent=runCount; $("#saveStatus").textContent="● Preview updated";
}
function updateStats(){ $("#projectCount").textContent=projects.length; }
function renderProjects(){
  const grid=$("#projectGrid"); if(!grid)return;
  const q=($("#projectSearch")?.value||"").toLowerCase();
  const list=projects.filter(p=>p.name.toLowerCase().includes(q));
  if(!list.length){grid.innerHTML='<div class="page-empty">No projects found. Create a new project to get started.</div>';return;}
  grid.innerHTML=list.map(p=>`<article class="project-card">
    <div class="project-top"><div class="project-icon">&lt;/&gt;</div><span class="pill">${p.id===currentId?"OPEN":"SAVED"}</span></div>
    <h3>${escapeHtml(p.name)}</h3><p>HTML · CSS · JavaScript</p>
    <div class="project-meta">Last saved: ${new Date(p.updated||Date.now()).toLocaleString()}</div>
    <div class="project-actions"><button class="btn btn-primary" data-open="${p.id}">Open</button><button class="btn btn-quiet" data-rename="${p.id}">Rename</button><button class="btn btn-quiet" data-delete="${p.id}">Delete</button></div>
  </article>`).join("");
  $$("[data-open]",grid).forEach(b=>b.onclick=()=>openProject(b.dataset.open));
  $$("[data-rename]",grid).forEach(b=>b.onclick=()=>renameProject(b.dataset.rename));
  $$("[data-delete]",grid).forEach(b=>b.onclick=()=>deleteProject(b.dataset.delete));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function openProject(id){
  syncEditorToProject(); currentId=id; const p=currentProject();
  switchTab(activeTab); $("#crumbPage").textContent=p.name; renderProjects(); showPage("workspace"); runCode(); toast("Project opened.");
}
function createProject(){
  syncEditorToProject();
  const name=prompt("What should your new project be called?","Untitled project");
  if(name===null)return;
  const p={id:uid(),name:name.trim()||"Untitled project",html:starter.html,css:starter.css,js:starter.js,updated:Date.now()};
  projects.unshift(p);currentId=p.id;activeTab="html";$("#codeEditor").value=p.html;
  $$(".file-tab").forEach(b=>b.classList.toggle("active",b.dataset.tab==="html"));
  $("#editorLang").textContent="HTML";persist(false);showPage("workspace");runCode();toast("New project created.");
}
function renameProject(id){
  const p=projects.find(x=>x.id===id);if(!p)return;
  const name=prompt("New project name:",p.name);if(name===null)return;
  p.name=name.trim()||p.name;p.updated=Date.now();persist(false);$("#crumbPage").textContent=currentProject().name;toast("Project renamed.");
}
function deleteProject(id){
  const p=projects.find(x=>x.id===id);if(!p)return;
  if(!confirm(`Delete "${p.name}"? This cannot be undone unless you have a backup.`))return;
  projects=projects.filter(x=>x.id!==id);
  if(!projects.length)projects=[{id:uid(),name:"My first webpage",...starter,updated:Date.now()}];
  if(currentId===id){currentId=projects[0].id;switchTab(activeTab);runCode();}
  persist(false);toast("Project deleted.");
}
function showPage(page){
  $$(".page").forEach(el=>el.classList.toggle("active",el.id==="page-"+page));
  $$(".nav-item").forEach(el=>el.classList.toggle("active",el.dataset.page===page));
  $("#crumbPage").textContent=({workspace:"Editor",projects:"My projects",learn:"Learn coding",python:"Python lab",share:"Share & export",account:"Account demo"})[page]||page;
  $("#sidebar").classList.remove("open");
}
function download(name,content,type){
  const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function exportAll(){syncEditorToProject();persist(false);download("COKOcoding-backup.json",JSON.stringify({format:"COKOcoding-backup-v1",projects},null,2),"application/json");toast("Backup downloaded.");}
function importAll(file){
  const reader=new FileReader();reader.onload=()=>{
    try{
      const data=JSON.parse(reader.result);const incoming=Array.isArray(data)?data:data.projects;
      if(!Array.isArray(incoming))throw new Error("This file does not contain a project list.");
      const valid=incoming.filter(p=>p&&typeof p.name==="string"&&typeof p.html==="string"&&typeof p.css==="string"&&typeof p.js==="string")
        .map(p=>({id:uid(),name:p.name,html:p.html,css:p.css,js:p.js,updated:Date.now()}));
      if(!valid.length)throw new Error("No valid projects were found.");
      projects=[...valid,...projects];currentId=valid[0].id;persist(false);switchTab("html");runCode();toast(`Imported ${valid.length} project(s).`);
    }catch(e){alert("Could not import backup: "+e.message);}
  };reader.readAsText(file);
}
function loadLesson(kind){
  if(kind==="html"){currentProject().html='<h1>My name is Coder</h1>\\n<p>I am learning HTML.</p>\\n<button id="hello">Say hello</button>\\n<p id="out"></p>';currentProject().css='body { font-family: sans-serif; padding: 30px; color: #25213d; }\\nbutton { padding: 10px 14px; border: 0; border-radius: 8px; background: #7658f6; color: white; cursor: pointer; }';currentProject().js='document.querySelector("#hello").onclick = () => {\\n  document.querySelector("#out").textContent = "Hello!";\\n};';}
  if(kind==="css"){currentProject().html='<div class="box"><h1>Style me!</h1><p>Change the CSS colours.</p></div>';currentProject().css='body { font-family: sans-serif; min-height: 100vh; display: grid; place-items: center; background: #f3efff; }\\n.box { padding: 35px; background: white; color: #6b4cf5; border-radius: 20px; box-shadow: 0 12px 35px #0001; }';currentProject().js='console.log("CSS makes pages beautiful!");';}
  if(kind==="js"){currentProject().html='<h1>Button challenge</h1>\\n<button id="change">Change the message</button>\\n<p id="message">Click the button.</p>';currentProject().css='body { font-family: sans-serif; padding: 30px; }\\nbutton { padding: 12px; border: 0; border-radius: 8px; background: #7658f6; color: white; }';currentProject().js='document.querySelector("#change").onclick = () => {\\n document.querySelector("#message").textContent = "JavaScript is working!";\\n};';}
  currentProject().updated=Date.now();activeTab="html";switchTab("html");showPage("workspace");runCode();toast("Lesson loaded into the editor.");
}

$$(".nav-item").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$$(".file-tab").forEach(b=>b.addEventListener("click",()=>switchTab(b.dataset.tab)));
$("#codeEditor").value=currentProject().html;
$("#codeEditor").addEventListener("input",()=>{syncEditorToProject();$("#saveStatus").textContent="● Unsaved edits";});
$("#runBtn").onclick=runCode;$("#refreshBtn").onclick=runCode;$("#topSave").onclick=()=>{syncEditorToProject();persist(true);};
$("#resetBtn").onclick=()=>{if(confirm("Reset the current project's HTML, CSS and JavaScript to the starter example?")){Object.assign(currentProject(),{...starter,updated:Date.now()});switchTab(activeTab);runCode();persist(false);toast("Starter code restored.");}};
$("#clearConsole").onclick=()=>$("#consoleOutput").textContent="";
$("#projectSearch").addEventListener("input",renderProjects);
$("#newProjectBtn").onclick=createProject;
$("#importProjectBtn").onclick=()=>$("#importFile").click();
$("#shareImportBtn").onclick=()=>$("#importFile").click();
$("#importFile").onchange=e=>{if(e.target.files[0])importAll(e.target.files[0]);e.target.value="";};
$("#exportJson").onclick=exportAll;
$("#downloadHtml").onclick=()=>{syncEditorToProject();download((currentProject().name||"webpage").replace(/[^a-z0-9-_]+/gi,"-")+".html",buildDocument(currentProject()),"text/html");toast("HTML file downloaded.");};
$$(".load-lesson").forEach(b=>b.onclick=()=>loadLesson(b.dataset.lesson));
$$("[data-goto]").forEach(b=>b.onclick=()=>showPage(b.dataset.goto));
$("#pythonExample").onclick=()=>{$("#pythonEditor").value='for i in range(1, 6):\\n    print("Hello from Python", i)';toast("Example loaded.");};
$("#pythonRun").onclick=async()=>{
  const code=$("#pythonEditor").value;const out=$("#pythonOutput");out.textContent="Running…";
  try{
    const response=await fetch("https://emkc.org/api/v2/piston/execute",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({language:"python",version:"3.10.0",files:[{content:code}]})});
    if(!response.ok)throw new Error("Online runner returned "+response.status);
    const data=await response.json();out.textContent=(data.run?.output||data.compile?.output||"No output.")+(data.run?.stderr?("\\n"+data.run.stderr):"");
  }catch(e){out.textContent="Could not reach the online Python runner. Check your internet connection, or try again later.\\n\\n"+e.message;}
};
$("#clearPython").onclick=()=>$("#pythonOutput").textContent="";
$("#themeBtn").onclick=()=>{document.body.classList.toggle("light-mode");localStorage.setItem("cokocoding_theme",document.body.classList.contains("light-mode")?"light":"dark");};
if(localStorage.getItem("cokocoding_theme")==="light")document.body.classList.add("light-mode");
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
$("#saveName").onclick=()=>{const n=$("#nameInput").value.trim()||"Guest Coder";localStorage.setItem(PROFILE_KEY,n);$("#profileName").textContent=n;toast("Display name saved locally.");};
const savedName=localStorage.getItem(PROFILE_KEY);if(savedName){$("#nameInput").value=savedName;$("#profileName").textContent=savedName;}
document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key==="Enter"){e.preventDefault();runCode();}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="s"){e.preventDefault();syncEditorToProject();persist(true);}});
window.addEventListener("beforeunload",()=>{try{syncEditorToProject();localStorage.setItem(STORE_KEY,JSON.stringify(projects));}catch(e){}});
updateStats();renderProjects();runCode();
