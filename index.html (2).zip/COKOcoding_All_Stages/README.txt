COKOcoding — All Stages in One Website
======================================

FILES
- index.html : page layout
- styles.css : design and responsive layout
- app.js     : editor, projects, lessons, exports, Python runner

RUN LOCALLY (Windows)
1. Download COKOcoding_All_Stages.zip.
2. Open Downloads in File Explorer.
3. Right-click the ZIP and choose Extract All.
4. Open the extracted COKOcoding_All_Stages folder.
5. Double-click index.html to open it in Chrome or Edge.
6. Edit HTML/CSS/JavaScript, then click Run code.

FEATURES INCLUDED
- Responsive dark developer UI and light theme toggle
- HTML, CSS and JavaScript editor tabs with live preview
- Create/open/rename/delete projects
- Local browser saving (localStorage)
- Download a standalone HTML page
- Export/import JSON project backups
- Beginner lessons that load sample code
- Python lab using the Piston online runner (requires internet)
- Demo profile name saved locally
- Mobile-friendly sidebar
- Ctrl+Enter to run and Ctrl+S to save

IMPORTANT LIMITS
- Projects are saved in this browser on this computer only.
- The account page is a demo; it does not create real accounts or store passwords.
- There is no server-backed cloud save, collaboration, public share URL, or real AI assistant in this package.
- Python execution calls a third-party service; availability and terms may change.
- For a public website, upload these three files to a static host. For real accounts/cloud saves/AI, add a secure backend and never put secret API keys in app.js.

This is a starter platform. Test before using for important work.
